@echo off
setlocal
title TotyShop - Atualizar painel
cd /d "%~dp0"
echo ============================================
echo   TotyShop - ATUALIZAR O PAINEL
echo ============================================
echo.
echo Pasta: %~dp0
echo.
if not exist "backend\dropper_bling_create.py" (
  echo ERRO: este arquivo precisa ficar DENTRO da pasta do projeto.
  echo.
  pause
  exit /b 1
)
if exist "frontend\build\.stamp-v4" del /q "frontend\build\.stamp-v4"
echo Remontando o painel. Pode demorar alguns minutos.
echo.
pause
call "%~dp0iniciar_totyshop.bat"
