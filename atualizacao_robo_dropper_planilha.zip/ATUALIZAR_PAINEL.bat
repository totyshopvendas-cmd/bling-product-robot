@echo off
setlocal
title TotyShop - Atualizar painel
cd /d "%~dp0"

echo ============================================
echo   TotyShop - ATUALIZAR O PAINEL
echo ============================================
echo.
echo Pasta: %~dp0
echo.

if not exist "backend\dropper_reader.py" (
  echo ERRO: este arquivo precisa ficar DENTRO da pasta do projeto.
  echo Copie ele para a pasta onde esta o iniciar_totyshop.bat.
  echo.
  pause
  exit /b 1
)

echo Removendo a marca do painel antigo para remontar...
if exist "frontend\build\.stamp-v4" del /q "frontend\build\.stamp-v4"
echo.
echo Abrindo o painel. Pode demorar alguns minutos.
echo NAO FECHE a janela do painel depois que ela abrir.
echo.
pause
call "%~dp0iniciar_totyshop.bat"
