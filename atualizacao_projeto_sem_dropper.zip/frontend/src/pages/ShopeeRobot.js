import { useEffect, useState, useCallback } from "react";
import { api, endpoints } from "@/lib/api";
import { logger } from "@/lib/logger";
import { Play, Square, RefreshCw, Bot, AlertTriangle, CheckCircle2, Download, Loader2 } from "lucide-react";
import { toast } from "sonner";

const LOG_DOT_COLORS = {
  success: "bg-emerald-500",
  error: "bg-rose-500",
  warning: "bg-amber-500",
  info: "bg-zinc-400",
};

const POLL_INTERVAL_MS = 2500;

const STATE_META = {
  idle: { label: "Ocioso", color: "bg-zinc-100 text-zinc-700 border-zinc-300" },
  running: { label: "Em execução", color: "bg-emerald-100 text-emerald-700 border-emerald-400" },
  paused: { label: "Pausado", color: "bg-amber-100 text-amber-700 border-amber-400" },
  error: { label: "Erro", color: "bg-rose-100 text-rose-700 border-rose-400" },
};

export default function ShopeeRobotPage() {
  const [status, setStatus] = useState(null);
  const [maxProducts, setMaxProducts] = useState(5);
  const [dryRun, setDryRun] = useState(true);
  const [logs, setLogs] = useState([]);
  const [chromium, setChromium] = useState(null);
  const [installing, setInstalling] = useState(false);

  const tick = useCallback(async () => {
    try {
      const [{ data: s }, { data: l }, { data: c }] = await Promise.all([
        api.get("/shopee/status"),
        api.get("/robot/logs?bot=shopee&limit=50"),
        api.get("/system/chromium-status"),
      ]);
      setStatus(s);
      setLogs(l);
      setChromium(c);
    } catch (err) {
      logger.error("Failed to fetch shopee robot status/logs:", err);
    }
  }, []);

  useEffect(() => {
    tick();
    const timer = setInterval(tick, POLL_INTERVAL_MS);
    return () => clearInterval(timer);
  }, [tick]);

  const installChromium = async () => {
    setInstalling(true);
    try {
      const { data } = await api.post("/system/install-chromium");
      if (data.already_installed) {
        toast.success("Chromium já está pronto");
      } else {
        toast.message("Instalação iniciada — aguarde 30-60s");
      }
      const startTs = Date.now();
      const poll = setInterval(async () => {
        try {
          const { data: c } = await api.get("/system/chromium-status");
          setChromium(c);
          if (c.installed || Date.now() - startTs > 180000) {
            clearInterval(poll);
            setInstalling(false);
            if (c.installed) toast.success("Chromium instalado!");
          }
        } catch (err) {
          logger.error("poll chromium:", err);
        }
      }, 4000);
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Falha");
      setInstalling(false);
    }
  };

  const start = async () => {
    if (!dryRun && chromium && !chromium.installed) {
      toast.error("Chromium não está pronto — clique em 'Instalar Chromium' primeiro");
      return;
    }
    try {
      await api.post("/shopee/start", { max_products: parseInt(maxProducts, 10) || 5, dry_run: dryRun });
      toast.success("Robô Shopee iniciado");
      tick();
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Falha ao iniciar");
    }
  };

  const stop = async () => {
    await api.post("/shopee/stop");
    toast.info("Parada solicitada");
    tick();
  };

  const meta = STATE_META[status?.state] || STATE_META.idle;
  const chromiumReady = chromium?.installed;

  return (
    <div className="space-y-6">
      <div>
        <div className="label-overline mb-1">Automação Shopee</div>
        <h1 className="font-display text-3xl font-bold tracking-tighter">Robô de Cadastro Shopee</h1>
        <p className="text-sm text-muted-foreground mt-1 max-w-3xl">
          O robô faz login no JohnDrop, abre o catálogo “Todos que eu não cadastrei”, seleciona a integração
          <strong> TotyShop-Shopee</strong>, limpa o título, busca o preço, escolhe a categoria compatível e cadastra o produto.
        </p>
        <p className="text-xs text-amber-700 mt-2 max-w-3xl">
          ⚠️ Por padrão começa em <strong>MODO TESTE (Dry-Run)</strong> — só simula sem cadastrar.
          Desmarque a caixa para cadastrar de verdade.
        </p>
      </div>

      {chromium && (
        <div
          className={`border p-4 flex items-center justify-between gap-4 ${
            chromiumReady
              ? "bg-emerald-50 border-emerald-300 text-emerald-900"
              : "bg-rose-50 border-rose-300 text-rose-900"
          }`}
        >
          <div className="flex items-center gap-3">
            {chromiumReady ? (
              <CheckCircle2 className="h-5 w-5 flex-shrink-0" />
            ) : installing ? (
              <Loader2 className="h-5 w-5 flex-shrink-0 animate-spin" />
            ) : (
              <AlertTriangle className="h-5 w-5 flex-shrink-0" />
            )}
            <div className="text-sm">
              <div className="font-semibold">
                {chromiumReady
                  ? "Chromium pronto"
                  : installing
                  ? "Instalando Chromium…"
                  : "Chromium não instalado"}
              </div>
              <div className="text-xs opacity-80 font-mono">
                {chromiumReady
                  ? chromium.path
                  : "Sem Chromium, o robô não consegue executar."}
              </div>
            </div>
          </div>
          {!chromiumReady && (
            <button
              onClick={installChromium}
              disabled={installing}
              className="text-sm font-medium px-4 py-2 rounded-sm bg-rose-700 text-white hover:bg-rose-800 disabled:opacity-60 inline-flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              {installing ? "Instalando…" : "Instalar Chromium"}
            </button>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 border border-border bg-white p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="label-overline mb-1">Estado atual</div>
              <span
                className={`inline-flex px-3 py-1 text-xs font-semibold border ${meta.color} rounded-sm uppercase`}
              >
                {status?.state === "running" && <span className="h-2 w-2 rounded-full bg-emerald-500 status-pulse mr-2 my-auto" />}
                {meta.label}
              </span>
            </div>
            <Bot className="h-8 w-8 text-zinc-300" strokeWidth={1.5} />
          </div>

          {status?.current_product && (
            <div className="bg-zinc-50 border border-border p-3 text-sm">
              <div className="label-overline mb-1">Processando</div>
              <div className="font-mono truncate">{status.current_product}</div>
            </div>
          )}

          <div className="grid grid-cols-3 border border-border divide-x divide-border">
            <div className="p-4">
              <div className="label-overline">Processados</div>
              <div className="font-display text-2xl font-bold">{status?.processed || 0}</div>
            </div>
            <div className="p-4">
              <div className="label-overline">Sucessos</div>
              <div className="font-display text-2xl font-bold text-emerald-600">{status?.success || 0}</div>
            </div>
            <div className="p-4">
              <div className="label-overline">Falhas</div>
              <div className="font-display text-2xl font-bold text-rose-600">{status?.failed || 0}</div>
            </div>
          </div>

          {status?.message && (
            <div className="bg-rose-50 border border-rose-200 text-rose-700 text-sm p-3 flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 mt-0.5" />
              <span>{status.message}</span>
            </div>
          )}
        </div>

        <div className="border border-border bg-white p-6 space-y-4">
          <div className="label-overline">Controles</div>
          <div>
            <label className="text-xs text-muted-foreground">Máx. produtos por execução</label>
            <input
              type="number"
              min={1}
              max={100}
              value={maxProducts}
              onChange={(e) => setMaxProducts(e.target.value)}
              className="w-full text-sm border border-border rounded-sm px-3 py-2 mt-1 focus:outline-none focus:ring-2 focus:ring-[#EE7B22]"
            />
          </div>
          <label
            className={`flex items-start gap-2 text-sm cursor-pointer p-3 rounded-sm border ${
              dryRun ? "bg-amber-50 border-amber-300" : "bg-emerald-50 border-emerald-300"
            }`}
          >
            <input
              type="checkbox"
              checked={dryRun}
              onChange={(e) => setDryRun(e.target.checked)}
              className="h-4 w-4 mt-0.5"
            />
            <div className="flex-1">
              <div className="font-semibold">
                {dryRun ? "🟡 MODO TESTE (Dry-Run)" : "🟢 MODO REAL"}
              </div>
              <div className="text-xs mt-1 text-zinc-700">
                {dryRun
                  ? "Robô SIMULA o cadastro sem clicar 'Criar Produto' — NADA será salvo."
                  : "Robô CADASTRA de verdade na Shopee via JohnDrop."}
              </div>
            </div>
          </label>

          <div className="flex flex-col gap-2 pt-2">
            <button
              onClick={start}
              disabled={status?.state === "running"}
              className={`w-full text-white text-sm font-medium px-4 py-2.5 rounded-sm disabled:opacity-50 inline-flex items-center justify-center gap-2 ${
                dryRun
                  ? "bg-[#EE7B22] hover:bg-[#C9651A]"
                  : "bg-emerald-600 hover:bg-emerald-700"
              }`}
            >
              <Play className="h-4 w-4" />
              {dryRun ? "Iniciar Robô Shopee (Teste)" : "Iniciar Robô Shopee (REAL)"}
            </button>
            <button
              onClick={stop}
              disabled={status?.state !== "running"}
              className="w-full border border-border text-sm font-medium px-4 py-2.5 rounded-sm hover:bg-zinc-50 disabled:opacity-50 inline-flex items-center justify-center gap-2"
            >
              <Square className="h-4 w-4" />
              Parar
            </button>
            <button
              onClick={tick}
              className="w-full text-xs text-muted-foreground hover:text-foreground inline-flex items-center justify-center gap-1.5 py-1"
            >
              <RefreshCw className="h-3.5 w-3.5" /> Atualizar
            </button>
          </div>
        </div>
      </div>

      <div className="border border-border bg-white">
        <div className="px-6 py-3 border-b border-border flex items-center justify-between">
          <span className="label-overline">Logs ao vivo do robô Shopee (50 últimos)</span>
          <span className="text-xs text-muted-foreground">{logs.length} entradas</span>
        </div>
        <div className="max-h-[420px] overflow-y-auto divide-y divide-border">
          {logs.length === 0 ? (
            <div className="px-6 py-12 text-sm text-muted-foreground text-center">
              Nenhum log ainda. Inicie o robô para ver atividade.
            </div>
          ) : (
            logs.map((log) => (
              <div key={log.id} className="px-6 py-3 flex items-start gap-4 text-sm">
                <span
                  className={`mt-1 inline-block h-2 w-2 rounded-full flex-shrink-0 ${LOG_DOT_COLORS[log.level] || LOG_DOT_COLORS.info}`}
                />
                <div className="flex-1 min-w-0">
                  <div className="font-mono text-xs text-muted-foreground">
                    {new Date(log.created_at).toLocaleTimeString("pt-BR")}
                  </div>
                  <div className="truncate">{log.message}</div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
