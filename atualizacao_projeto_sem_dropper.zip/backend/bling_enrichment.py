"""Bling enrichment service.

After JohnDrop cadastros a product, JohnDrop automatically syncs it to Bling.
This service then ENRICHES the Bling product with:
  1. Short description (rewritten from JohnDrop raw description — SEO + readability)
  2. Exactly 8 bullet points (max 150 chars each)
  3. Best-matching Bling category (or creates one if none exists)

Rules for descriptions:
- No brand names (XLS, Kapbom, etc) or EAN/GTIN
- Only <b>bold</b> and hyphens (-) allowed
- Variations (cores/tamanhos/modelos) must be preserved & highlighted in short description
"""
import os
import re
import uuid
import json
import asyncio
from typing import Optional, List
from datetime import datetime, timezone

from ai_client import LlmChat, UserMessage, ImageContent, has_text_ai, has_image_ai

import bling_service
from db import db
from robot_service import add_log
from color_variation_guard import filter_variations_by_color, _is_color_name


LLM_PROVIDER = "anthropic"
LLM_MODEL = "claude-haiku-4-5-20251001"

# ----------------------------------------------------------------- marca -----
# Configurada em Configurações → Marca dos produtos.
#   mode = "fabricante": detecta a marca real do fabricante; se não houver, usa o nome da loja.
#   mode = "loja":       usa sempre o nome da loja como marca.
_BRAND_SETTINGS_CACHE: dict = {"mode": None, "store_name": None, "checked": False}


async def _get_brand_settings() -> dict:
    if _BRAND_SETTINGS_CACHE["checked"]:
        return {"mode": _BRAND_SETTINGS_CACHE["mode"], "store_name": _BRAND_SETTINGS_CACHE["store_name"] or ""}
    doc = await db.settings.find_one({"key": "brand_settings"}, {"_id": 0})
    val = (doc or {}).get("value") or {}
    _BRAND_SETTINGS_CACHE["mode"] = val.get("mode", "fabricante")
    _BRAND_SETTINGS_CACHE["store_name"] = (val.get("store_name") or "").strip()
    _BRAND_SETTINGS_CACHE["checked"] = True
    return {"mode": _BRAND_SETTINGS_CACHE["mode"], "store_name": _BRAND_SETTINGS_CACHE["store_name"]}


def _reset_brand_cache() -> None:
    _BRAND_SETTINGS_CACHE["checked"] = False


_BRAND_SYSTEM = (
    "Você identifica a MARCA DO FABRICANTE de um produto a partir do título e da descrição. "
    "Responda APENAS com o nome da marca (ex: Samsung, Nike, Philips) ou a palavra NENHUMA se não "
    "for possível identificar uma marca de fabricante. "
    "Não responda com nomes de varejo, marketplace, loja ou genéricos como 'Generico'."
)


async def _detect_brand_ai(raw_title: str, raw_description: str) -> Optional[str]:
    """Usa IA para detectar a marca real do fabricante. Retorna None se não houver marca."""
    if not has_text_ai():
        return None
    user = (
        f"Título: {raw_title or ''}\n"
        f"Descrição: {(raw_description or '')[:800]}\n\n"
        "Qual é a marca do fabricante? Responda apenas o nome da marca ou NENHUMA."
    )
    try:
        text = await _llm_call(_BRAND_SYSTEM, user)
    except Exception:
        return None
    t = (text or "").strip().strip('"').strip("'")
    if not t or t.upper() in {"NENHUMA", "N/A", "NA", "NENHUM", "-"}:
        return None
    # Limpa a resposta para conter só o nome da marca (primeira linha, sem pontuação extra)
    t = t.split("\n")[0]
    t = re.sub(r"[^A-Za-zÀ-ÿ0-9 .&\-]", " ", t).strip()
    return t or None


async def _resolve_brand(raw_title: str, raw_description: str) -> str:
    """Resolve a marca final conforme o modo escolhido pelo usuário."""
    settings = await _get_brand_settings()
    mode = settings.get("mode", "fabricante")
    store_name = settings.get("store_name") or ""

    if mode == "loja":
        return store_name or "Generico"

    # modo fabricante: tenta IA; se não achar, usa o nome da loja (o "____")
    detected = await _detect_brand_ai(raw_title, raw_description)
    if detected:
        return detected
    return store_name or "Generico"


# ------------------------------------------------- atributos (item 5) --------
_ATTRIBUTES_SYSTEM = (
    "Você extrai dados estruturados de um produto para preencher cadastros de "
    "marketplaces (Mercado Livre, Shopee etc.). Responda APENAS com um JSON válido, "
    "sem texto antes nem depois, com estas chaves (use string vazia []/'' quando não souber):\n"
    '{"modelo": "", "material": "", "cor": "", "voltagem": "", "dimensoes": "", "palavras_chave": []}\n'
    "- modelo: nome/modelo do produto (ex: 'KA-S079', 'XLS B125').\n"
    "- material: material predominante (ex: 'plástico', 'alumínio', 'silicone').\n"
    "- cor: cor principal do produto.\n"
    "- voltagem: '110V', '220V', 'Bivolt' ou '' se não for elétrico.\n"
    "- dimensoes: medidas do produto se mencionadas (ex: '30x20x5 cm').\n"
    "- palavras_chave: até 6 palavras-chave curtas para busca."
)


async def _extract_attributes(raw_title: str, raw_description: str) -> dict:
    """Extrai modelo, material, cor, voltagem, dimensões e palavras-chave via IA."""
    if not has_text_ai():
        return {}
    user = (
        f"Título: {raw_title or ''}\n"
        f"Descrição: {(raw_description or '')[:1200]}\n\n"
        "Extraia os atributos acima em JSON."
    )
    try:
        text = await _llm_call(_ATTRIBUTES_SYSTEM, user)
    except Exception:
        return {}
    m = re.search(r"\{[^{}]*\}", text, re.DOTALL)
    if not m:
        return {}
    try:
        data = json.loads(m.group(0))
        return {
            "modelo": str(data.get("modelo") or "").strip(),
            "material": str(data.get("material") or "").strip(),
            "cor": str(data.get("cor") or "").strip(),
            "voltagem": str(data.get("voltagem") or "").strip(),
            "dimensoes": str(data.get("dimensoes") or "").strip(),
            "palavras_chave": data.get("palavras_chave") or [],
        }
    except Exception:
        return {}


def _attributes_to_bullets(attrs: dict) -> List[str]:
    """Converte os atributos extraídos em bullets de 'Ficha Técnica' (máx 6)."""
    bullets: List[str] = []
    labels = {
        "modelo": "Modelo",
        "material": "Material",
        "cor": "Cor",
        "voltagem": "Voltagem",
        "dimensoes": "Dimensões",
    }
    for key, label in labels.items():
        val = attrs.get(key) or ""
        if val:
            bullets.append(f"- <b>{label}:</b> {val}")
    keys = attrs.get("palavras_chave") or []
    if keys:
        bullets.append(f"- <b>Palavras-chave:</b> {', '.join(keys[:6])}")
    return bullets[:6]


# ------------------------------------------------- visão de cor (item 1) -----
_COLOR_VISION_SYSTEM = (
    "Você recebe fotos de um produto e uma lista de NOMES DE CORES em português. "
    "Diga APENAS quais dessas cores realmente aparecem nas fotos do produto. "
    "Responda APENAS um JSON válido: {\"cores_confirmadas\": [\"azul\", \"preto\"]}. "
    "Não invente cores que não estejam visíveis. Se nenhuma das cores listadas aparecer, "
    "devolva a lista vazia. Considere embalagem e fundo, não apenas o produto."
)


async def _confirm_colors_by_vision(images: Optional[list], color_names: List[str]) -> List[str]:
    """Usa IA de visão para confirmar quais das cores informadas aparecem nas fotos.

    Retorna apenas as cores confirmadas. Cores não confirmadas ficam de fora das
    variações e vão para revisão (item 1: se a cor da foto não bater, não cadastra errado).
    """
    if not has_image_ai() or not images or not color_names:
        return []
    # Monta as mensagens com até 8 imagens (limite de custo/token).
    image_contents: List[ImageContent] = []
    for u in images[:8]:
        if isinstance(u, str) and u.startswith("http"):
            # Baixa a imagem e converte para base64 para enviar ao provedor de IA.
            try:
                import requests
                r = requests.get(u, timeout=20)
                if r.status_code == 200 and r.content:
                    import base64
                    b64 = base64.b64encode(r.content).decode()
                    mime = "image/jpeg"
                    image_contents.append(ImageContent(b64, mime))
            except Exception:
                continue
        elif isinstance(u, str):
            image_contents.append(ImageContent(u))
    if not image_contents:
        return []
    user_text = (
        "Cores para verificar: " + ", ".join(color_names) + "\n"
        "Qual dessas cores aparece nas fotos? Responda em JSON."
    )
    try:
        chat = LlmChat(
            session_id=f"color-vision-{uuid.uuid4()}",
            system_message=_COLOR_VISION_SYSTEM,
        ).with_model("gemini", "gemini-2.5-flash-image")
        response = await chat.send_message(UserMessage(text=user_text, file_contents=image_contents))
    except Exception:
        # fallback: tenta openai se gemini não tiver chave/imagem
        try:
            chat = LlmChat(
                session_id=f"color-vision-{uuid.uuid4()}",
                system_message=_COLOR_VISION_SYSTEM,
            ).with_model("openai", "gpt-4o-mini")
            response = await chat.send_message(UserMessage(text=user_text, file_contents=image_contents))
        except Exception:
            return []
    m = re.search(r"\{[^{}]*\}", response or "", re.DOTALL)
    if not m:
        return []
    try:
        data = json.loads(m.group(0))
        confirmed = [str(c).strip().lower() for c in (data.get("cores_confirmadas") or [])]
        return [c for c in confirmed if c]
    except Exception:
        return []


def _normalize_color_for_vision(value: str) -> str:
    """Normaliza um nome de cor para comparação (minúsculo, sem acento simples)."""
    if not value:
        return ""
    v = value.strip().lower()
    aliases = {
        "azul claro": "azul", "azul escuro": "azul", "branca": "branco", "preta": "preto",
        "vermelha": "vermelho", "verde claro": "verde", "verde escuro": "verde",
        "amarela": "amarelo", "rosa claro": "rosa", "roxa": "roxo", "cinza claro": "cinza",
        "cinza escuro": "cinza", "dourada": "dourado",
    }
    return aliases.get(v, v)


async def _save_review(
    sku: str, reason: str, details: list, raw_title: str, raw_description: str, images: Optional[list]
) -> None:
    """Registra um item na fila de revisão (quando a IA não confirma uma cor, por exemplo)."""
    try:
        await db.review_queue.update_one(
            {"sku": sku, "reason": reason},
            {"$set": {
                "sku": sku,
                "reason": reason,
                "details": details,
                "raw_title": raw_title,
                "raw_description": raw_description,
                "images": images,
                "status": "pending",
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }},
            upsert=True,
        )
    except Exception as e:
        await add_log("warning", f"Falha ao salvar revisão para {sku}: {e}")


# --------------------------------------------------- sortido (item 2) --------
SORTIDO_RE = re.compile(
    r"(conforme\s+(?:a\s+)?disponibilidade\s+(?:do\s+|de\s+)?estoque|"
    r"seguindo\s+(?:a\s+)?disponibilidade|"
    r"de\s+acordo\s+com\s+(?:o\s+|a\s+)?(?:estoque|disponibilidade)|"
    r"enviad[oa]s?\s+conforme\s+(?:a\s+)?disponibilidade|"
    r"sujeit[oa]s?\s+(?:à|a)\s+disponibilidade|"
    r"\bsortid[oa]s?\b|\bvariad[oa]s?\b|\bconforme\s+estoque\b)",
    re.IGNORECASE,
)


def _is_sortido(raw_description: str) -> bool:
    """True quando o fornecedor envia cor/modelo conforme estoque (sortido/variado)."""
    if not raw_description:
        return False
    return bool(SORTIDO_RE.search(raw_description))

# Bling product sync may take a few seconds — retry finding the product
FIND_PRODUCT_MAX_ATTEMPTS = 18
FIND_PRODUCT_DELAY_S = 15

BLOCKED_BRAND_RE = re.compile(
    r"\b(XLS|Kapbom|Inova|Altomex|Eletromex|Hayamax|JONHDROP|Jonh Variedades|Variedades)\b",
    re.IGNORECASE,
)
EAN_RE = re.compile(r"\b\d{8,14}\b")


def _sanitize(text: str, preserve_newlines: bool = False) -> str:
    """Remove brand names + EAN sequences from any free text."""
    if not text:
        return ""
    text = BLOCKED_BRAND_RE.sub(" ", text)
    text = EAN_RE.sub(" ", text)
    if preserve_newlines:
        # Collapse spaces/tabs but keep newlines
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()
    return re.sub(r"\s+", " ", text).strip()


SHORT_DESC_SYSTEM = (
    "Você reformata descrições de produto do fornecedor JohnDrop para o Bling.\n"
    "REGRA DE OURO: PRESERVE o texto original do JohnDrop. Você é um REFORMATADOR, "
    "não um redator. Apenas:\n"
    "  (a) divide em parágrafos com \\n\\n\n"
    "  (b) aplica negrito <b>...</b> em rótulos de seção (ex: <b>Características:</b>)\n"
    "  (c) substitui bullets/asteriscos por hífen (- )\n"
    "PROIBIDO ALTERAR:\n"
    "  - Vocabulário (não troque sinônimos)\n"
    "  - Ordem das informações\n"
    "  - Detalhes técnicos (medidas, capacidade, materiais)\n"
    "  - Lista de cores/tamanhos/modelos disponíveis\n"
    "ÚNICAS REMOÇÕES PERMITIDAS:\n"
    "  1. Nomes de marca (XLS, Kapbom, Inova, Altomex, Eletromex, Aoshi, Lehmox, etc)\n"
    "  2. Códigos EAN/GTIN (sequências de 8-14 dígitos)\n"
    "PROIBIDO:\n"
    "  - Emojis, asteriscos, símbolos ° ™ ® (apenas <b>...</b> e hífen)\n"
    "  - Inventar características que não estão na descrição original\n"
    "  - Reescrever frases (apenas reformate o texto que já existe)\n"
    "  - Acrescentar slogans de marketing genéricos\n"
    "Se a descrição original já estiver bem escrita, copie-a quase literalmente, "
    "apenas dividindo em parágrafos com \\n\\n e aplicando negrito em rótulos.\n"
    "Responda APENAS o texto reformatado. Sem comentários."
)


BULLETS_SYSTEM = (
    "Você é um especialista em copywriting técnico para marketplaces. "
    "Gere EXATAMENTE 8 bullet points técnicos sobre o produto. "
    "REGRAS OBRIGATÓRIAS:\n"
    "1. EXATAMENTE 8 bullets — nem mais, nem menos.\n"
    "2. Cada bullet com MÁXIMO 150 caracteres.\n"
    "3. Cada bullet começa com hífen + espaço: '- '\n"
    "4. NUNCA inclua nomes de marca nem códigos EAN/GTIN.\n"
    "5. Permitido APENAS: negrito via <b>...</b> e hífen.\n"
    "   PROIBIDO: emojis, asteriscos, símbolos como ° ™ ®.\n"
    "6. Cada bullet deve destacar um benefício/característica DIFERENTE.\n"
    "7. Linguagem clara, direta, vendedora.\n"
    "Responda APENAS com os 8 bullets, um por linha. Sem cabeçalho, sem numeração, sem aspas."
)


CATEGORY_SYSTEM = (
    "Você é um especialista em categorização de produtos para o ERP Bling. "
    "Dada a descrição de um produto e uma lista de categorias disponíveis no Bling, "
    "escolha a categoria MAIS APROPRIADA. "
    "Responda APENAS com um JSON válido no formato:\n"
    '{"category_id": <id ou null>, "category_name": "<nome se for criar nova>", '
    '"confidence": "high"|"medium"|"low"}\n'
    "Use 'category_id' quando uma categoria existente couber bem (confidence=high ou medium). "
    "Use 'category_id: null' e 'category_name' com um nome curto/genérico se NENHUMA categoria existente couber. "
    "Categorias genéricas válidas: 'Eletrônicos', 'Beleza', 'Casa', 'Acessórios', 'Esporte', 'Brinquedos', 'Saúde'."
)


def _strip_emojis_and_special(text: str) -> str:
    """Strip emojis & forbidden characters, keep only letters, digits, punctuation, hyphen, <b> tags
    AND newline characters (for paragraph breaks)."""
    # Preserve <b>/</b> tags and newlines
    placeholder_open = "\x01BSTART\x01"
    placeholder_close = "\x01BEND\x01"
    placeholder_nl = "\x01NL\x01"
    text = text.replace("<b>", placeholder_open).replace("</b>", placeholder_close).replace("\n", placeholder_nl)
    text = re.sub(r"[^\w\s\-.,;:?!()\"\'áéíóúâêîôûãõàèìòùçÁÉÍÓÚÂÊÎÔÛÃÕÀÈÌÒÙÇ\x01A-Z]+", " ", text, flags=re.UNICODE)
    text = text.replace(placeholder_open, "<b>").replace(placeholder_close, "</b>").replace(placeholder_nl, "\n")
    # Collapse 3+ newlines to exactly 2 (paragraph break)
    text = re.sub(r"\n{3,}", "\n\n", text)
    # Collapse spaces but preserve newlines
    text = re.sub(r"[ \t]+", " ", text).strip()
    return text


# Abbreviation map for common Portuguese color/size names → 2-letter code
VARIATION_ABBR = {
    "rosa": "RS", "azul": "AZ", "verde": "VD", "amarelo": "AM", "preto": "PR",
    "branco": "BR", "vermelho": "VM", "cinza": "CZ", "roxo": "RX", "laranja": "LR",
    "marrom": "MR", "bege": "BG", "dourado": "DR", "prata": "PT", "vinho": "VH",
    "azul claro": "AC", "azul escuro": "AE", "rosa claro": "RC", "verde claro": "VC",
    "pequeno": "PQ", "medio": "MD", "grande": "GD", "extra grande": "XG",
    "p": "P", "m": "M", "g": "G", "gg": "GG", "pp": "PP", "xg": "XG", "xs": "XS",
}


def _abbreviate_variation(name: str) -> str:
    """Generate 2-letter abbreviation for a variation name."""
    key = name.lower().strip()
    if key in VARIATION_ABBR:
        return VARIATION_ABBR[key]
    # Fallback: take first 2 consonants/letters uppercase
    letters = re.sub(r"[^A-Za-zÀ-ÿ]", "", name).upper()
    if len(letters) >= 2:
        return letters[0] + letters[-1] if len(letters) > 3 else letters[:2]
    return letters or "VA"


def _parse_variation_quantities(raw_description: str, variations: List[str]) -> dict:
    """Detect explicit per-variation quantities AND out-of-stock markers in the description.

    Supported formats (case-insensitive):
      - "Rosa: 5"     /  "Rosa - 5"
      - "Rosa (5)"    /  "Rosa (5 unidades)"
      - "5 Rosa"      /  "5 unidades de Rosa"
      - "Rosa (esgotado)" / "Rosa (sem estoque)" → returns 0
      - "Rosa - Esgotado"                        → returns 0

    Returns {variation_name: qty} only for the variations explicitly quantified
    or marked as out-of-stock. Variations NOT present in the dict should get the
    equal split of remaining stock.
    """
    out: dict = {}
    if not raw_description or not variations:
        return out
    text = raw_description
    for v in variations:
        v_re = re.escape(v)
        # Out-of-stock markers FIRST (force 0)
        oos_patterns = [
            rf"{v_re}\s*[\(\-:]?\s*esgotad[oa]?",
            rf"{v_re}\s*[\(\-:]?\s*sem\s+estoque",
            rf"{v_re}\s*[\(\-:]?\s*indispon[ií]ve[il]",
            rf"{v_re}\s*[\(\-:]?\s*0\s*(?:un|unidad|peças?)?\s*\)?",
        ]
        is_oos = any(re.search(p, text, re.IGNORECASE) for p in oos_patterns)
        if is_oos:
            out[v] = 0
            continue

        patterns = [
            rf"{v_re}\s*[:\-–]\s*(\d{{1,4}})",
            rf"{v_re}\s*\(\s*(\d{{1,4}})\s*(?:un|unidad|pcs|peças?)?\s*\)",
            rf"(\d{{1,4}})\s+(?:un|unidade?s?|pcs)?\s*(?:de\s+)?{v_re}\b",
        ]
        for pat in patterns:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                try:
                    out[v] = int(m.group(1))
                    break
                except (TypeError, ValueError):
                    pass
    return out


def _parse_variations(raw_description: str) -> List[str]:
    """Extract variation names from descriptions following strict TotyShop rules:

    1. Must contain the trigger word "Disponível" / "Disponíveis" together with
       "cores" / "tamanhos" / "modelos". Without "Disponível", NO variations are
       extracted (avoids descriptive text being mistaken for variations).
    2. If the description says "conforme disponibilidade do estoque" / "seguindo
       a disponibilidade" / "de acordo com o estoque" anywhere, the seller doesn't
       let the buyer choose → NO variations extracted.
    3. Variations are STRICT: only single-word color/size/model names. Multi-word
       phrases (> 3 words) or descriptive sentences are filtered out.
    """
    if not raw_description:
        return []

    # GATE 1: "conforme disponibilidade do estoque" → buyer doesn't choose → no variations
    # Estes disclaimers bloqueiam qualquer tipo de variação (o vendedor manda
    # o que tiver, comprador não escolhe).
    global_disclaimers = [
        r"conforme\s+(?:a\s+)?disponibilidade\s+(?:do\s+|de\s+)?estoque",
        r"seguindo\s+(?:a\s+)?disponibilidade",
        r"de\s+acordo\s+com\s+(?:o\s+|a\s+)?(?:estoque|disponibilidade)",
        r"enviad[oa]s?\s+conforme\s+(?:a\s+)?disponibilidade",
        r"sujeit[oa]s?\s+(?:à|a)\s+disponibilidade",
    ]
    for dp in global_disclaimers:
        if re.search(dp, raw_description, re.IGNORECASE):
            return []

    # GATE 1b: disclaimers ESPECÍFICOS por tipo — "cor única" só bloqueia
    # variações de COR; "tamanho único" só bloqueia TAMANHO; etc.
    # Um produto pode ter "tamanho único" para adultos MAS ter 5 cores.
    blocked_kinds: set = set()
    if re.search(r"\bcor\s+(?:[úu]nica|do\s+produto|fixa|principal)\b", raw_description, re.IGNORECASE):
        blocked_kinds.add("cores")
    if re.search(r"\btamanho\s+(?:[úu]nico|fixo|padr[ãa]o)\b", raw_description, re.IGNORECASE):
        blocked_kinds.add("tamanhos")
    if re.search(r"\bmodelo\s+(?:[úu]nico|fixo|padr[ãa]o)\b", raw_description, re.IGNORECASE):
        blocked_kinds.add("modelos")

    # GATE 2: aceita PLURAL ("cores"/"tamanhos"/"modelos") sempre; aceita
    # SINGULAR ("cor"/"tamanho"/"modelo") APENAS quando o body tem múltiplos
    # itens listados abaixo — nesse caso é uma variação real, não descrição.
    patterns = [
        # Plural com "Disponível" prefixo — regra original
        (r"dispon[ií]ve[il]s?\s+(?:nas?|nos?|em|nas?\s+seguintes)?\s*(cores|tamanhos|modelos)[:\s]+([^.\n]+(?:\n[^.\n]+)*?)(?=\n\s*\n|$|\.|\bmedidas?\b|\bdimens|\bideal\b|\bpara\b\s+(?:setup|jogos|trabalho)|\bcaracter)", True),
        # Plural sem "Disponível" — "Cores disponíveis:"
        (r"(cores|tamanhos|modelos)\s+dispon[ií]ve[il]s?[:\s]+([^\.\n]+(?:\n[^\.\n]+)*?)(?=\n\s*\n|$|\.|\bmedidas?\b|\bdimens|\bideal\b|\bcaracter)", True),
        # Singular com "Disponível" — só será aceito se body tiver 2+ itens
        (r"dispon[ií]ve[il]s?\s+(?:nas?|nos?|em)\s*(cor|tamanho|modelo)[:\s]+([^\.\n]+(?:\n[^\.\n]+)*?)(?=\n\s*\n|$|\.|\bmedidas?\b|\bdimens|\bideal\b|\bcaracter)", False),
    ]
    body = ""
    kind = ""
    for pat, _is_plural in patterns:
        m = re.search(pat, raw_description, re.IGNORECASE)
        if m:
            kind = (m.group(1) or "").lower()
            body = m.group(2)
            break
    if not body:
        return []
    # Normaliza kind singular → plural para bater com blocked_kinds
    kind_normalized = {"cor": "cores", "tamanho": "tamanhos", "modelo": "modelos"}.get(kind, kind)
    if kind_normalized in blocked_kinds:
        return []

    # Split by hyphens, commas, semicolons, line breaks, AND coordinating conjunctions
    parts = re.split(r"\s*(?:[-,;\n]|\s+(?:e|ou)\s+)\s*", body, flags=re.IGNORECASE)
    out: List[str] = []
    for p in parts:
        p = p.strip(" -")
        if not p or len(p) > 30:
            continue
        # NOTE: we KEEP items marked as "(esgotado)" — variations with 0 stock should be
        # created in Bling with quantity=0 (per TotyShop manual). The status info is
        # extracted later by _parse_variation_quantities.
        # Remove parenthetical content (e.g. "(esgotado)" or "(5)") for the name itself
        p_clean = re.sub(r"\([^)]*\)", "", p).strip()
        if not p_clean or p_clean.lower() in {"e", "ou", "etc", "..."}:
            continue
        # FILTER: descriptive phrases ("Ideal Para Setups Temáticos" has 4 words)
        # Allow up to 3 words to keep compound colors ("Cinza com preto",
        # "Verde escuro", "Azul claro"). The descriptive_starts filter below
        # still catches "Ideal Para X", "Compatível com X" etc.
        words = p_clean.split()
        if len(words) > 3:
            continue
        # FILTER: phrases that start with descriptive adjectives
        descriptive_starts = {
            "ideal", "para", "perfeito", "indicado", "recomendado", "compatível",
            "compatíve", "com", "sem", "voltado", "destinado",
        }
        if words and words[0].lower() in descriptive_starts:
            continue
        # Normalize case
        p_clean = " ".join(w.capitalize() for w in words)
        out.append(p_clean)
    seen = set()
    deduped = []
    for v in out:
        kl = v.lower()
        if kl not in seen:
            seen.add(kl)
            deduped.append(v)
    # If only ONE option was extracted, it's a single-color/size product — not a variation
    if len(deduped) <= 1:
        return []
    # Se o padrão original usava singular ("Disponível na cor"), só aceita
    # quando de fato há múltiplas opções listadas (o que a regra acima já
    # garante, pois exige >= 2). Ok, retorna.
    return deduped[:10]


async def _find_supplier_id(supplier_name: str = "JONH VARIEDADES") -> Optional[int]:
    """Find a Bling supplier contact by name, with an isolated cache per supplier.

    Note: Bling's `pesquisa` param does NOT match multi-word queries verbatim, so we
    search by the first single word and filter the results client-side."""
    key = (supplier_name or "JONH VARIEDADES").strip().upper()
    cache = _SUPPLIER_CACHE.setdefault(key, {"id": None, "name": supplier_name})
    if cache["id"]:
        return cache["id"]
    try:
        search_term = key.split()[0] if key.split() else key
        resp = await bling_service.bling_request(
            "GET", "/contatos", params={"pesquisa": search_term, "limite": 50}
        )
        if resp.status_code >= 400:
            return None
        items = (resp.json() or {}).get("data") or []
        for it in items:
            nome = (it.get("nome") or "").upper().strip()
            if nome == key or key in nome or all(part in nome for part in key.split()):
                cache["id"] = it.get("id")
                cache["name"] = it.get("nome")
                return cache["id"]
    except Exception as e:
        await add_log("warning", f"Bling: falha ao buscar fornecedor {supplier_name}: {e}")
    return None


async def _llm_call(system: str, user_prompt: str) -> str:
    if not has_text_ai():
        raise RuntimeError("Nenhuma chave de IA configurada (Configurações → Inteligência Artificial)")
    chat = LlmChat(
        session_id=f"bling-enrich-{uuid.uuid4()}",
        system_message=system,
    ).with_model(LLM_PROVIDER, LLM_MODEL)
    response = await chat.send_message(UserMessage(text=user_prompt))
    return str(response).strip().strip('"').strip("'")


async def generate_short_description(raw_title: str, raw_description: str) -> str:
    user = (
        f"Título limpo: {raw_title}\n"
        f"Descrição original (do fornecedor):\n{raw_description or '(sem descrição original)'}\n\n"
        "Gere a descrição curta seguindo TODAS as regras do sistema. "
        "LEMBRE: separe os 3 a 5 parágrafos com duas quebras de linha (uma linha em branco entre eles)."
    )
    text = await _llm_call(SHORT_DESC_SYSTEM, user)
    text = _sanitize(text, preserve_newlines=True)
    text = _strip_emojis_and_special(text)
    return text[:2000]


async def generate_bullet_points(raw_title: str, raw_description: str) -> List[str]:
    user = (
        f"Título: {raw_title}\n"
        f"Descrição original: {raw_description or '(sem descrição)'}\n\n"
        "Gere EXATAMENTE 8 bullets."
    )
    raw = await _llm_call(BULLETS_SYSTEM, user)
    lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
    # Normalize: ensure each line starts with "- " and ≤150 chars
    cleaned: List[str] = []
    for ln in lines:
        ln = ln.lstrip("•*·").strip()
        if not ln.startswith("-"):
            ln = "- " + ln
        ln = _sanitize(ln)
        ln = _strip_emojis_and_special(ln)
        if len(ln) > 150:
            ln = ln[:150].rstrip()
        cleaned.append(ln)
    # Pad or truncate to exactly 8
    while len(cleaned) < 8:
        cleaned.append("- Produto de qualidade pronto para entrega rápida")
    return cleaned[:8]


async def _list_bling_categories() -> List[dict]:
    """Fetch all product categories from Bling. Returns list of {id, descricao}."""
    cats: List[dict] = []
    pagina = 1
    while pagina < 20:
        resp = await bling_service.bling_request("GET", "/categorias/produtos", params={"pagina": pagina, "limite": 100})
        if resp.status_code >= 400:
            break
        body = resp.json()
        items = body.get("data") or []
        if not items:
            break
        for it in items:
            cats.append({"id": it.get("id"), "descricao": it.get("descricao", "")})
        if len(items) < 100:
            break
        pagina += 1
    return cats


async def _create_bling_category(name: str) -> Optional[int]:
    """Create a new product category in Bling. Returns new id or None."""
    resp = await bling_service.bling_request(
        "POST", "/categorias/produtos", json={"descricao": name}
    )
    if resp.status_code >= 400:
        await add_log("warning", f"Falha ao criar categoria '{name}' no Bling: {resp.status_code}")
        return None
    try:
        body = resp.json()
        return (body.get("data") or {}).get("id")
    except Exception:
        return None


async def pick_or_create_category(raw_title: str, raw_description: str) -> Optional[int]:
    """Use LLM to pick best Bling category from EXISTING ones; never create new categories.

    Per TotyShop manual: "É proibida a criação desordenada de novas categorias pela IA.
    O robô deve buscar termos correspondentes que já existam criados no Bling."
    """
    cats = await _list_bling_categories()
    cat_list = "\n".join(f"- id={c['id']}: {c['descricao']}" for c in cats[:150])
    user = (
        f"Produto: {raw_title}\n"
        f"Descrição: {(raw_description or '')[:300]}\n\n"
        f"Categorias disponíveis no Bling:\n{cat_list or '(nenhuma)'}\n\n"
        f"IMPORTANTE: você só pode escolher entre as categorias listadas acima. "
        f"NUNCA invente uma nova. Se nenhuma servir, responda category_id=null."
    )
    raw = await _llm_call(CATEGORY_SYSTEM, user)
    m = re.search(r"\{[^{}]*\}", raw, re.DOTALL)
    json_str = m.group(0) if m else raw
    try:
        data = json.loads(json_str)
        cid = data.get("category_id")
        if cid:
            return int(cid)
    except Exception:
        await add_log("warning", f"Categoria: LLM retornou inválido — fallback keyword. Raw: {raw[:120]}")

    # Fallback keyword match against EXISTING categories only
    title_lower = (raw_title or "").lower()
    keyword_map = [
        ("Acessorios para Celular", ["controle gamer celular", "joystick celular", "gamepad celular", "manete celular"]),
        ("Pendrive", ["pendrive", "flash drive", "chaveiro 64gb", "chaveiro 32gb"]),
        ("Smartwatches", ["smartwatch", "smart watch"]),
        ("Relógios Digitais", ["relógio digital", "relogio digital"]),
        ("Câmeras de Segurança", ["câmera segurança", "camera seguranca", "babá eletrônica", "wifi 360"]),
        ("Soundbar Bluetooth", ["soundbar", "sound bar"]),
        ("Caixas de Som Bluetooth", ["caixa som", "caixa de som", "speaker bluetooth"]),
        ("Fones Bluetooth e TWS", ["fone bluetooth", "tws", "fone tws", "earbuds"]),
        ("Fones de Ouvido com Fio", ["fone ouvido", "fone intra"]),
        ("Headphone e Headset Bluetooth", ["headphone", "headset"]),
        ("Cabos USB-C (Tipo-C)", ["usb-c", "tipo-c", "type-c"]),
        ("Cabos V8 / Micro USB", ["micro usb", "v8", "cabo v8"]),
        ("Cabos Lightning / iOS", ["lightning", "ios cable"]),
        ("Carregadores de Parede Turbo", ["carregador parede", "carregador turbo"]),
        ("Carregadores Veiculares", ["carregador veicular", "carregador carro"]),
        ("Power Banks", ["power bank", "powerbank", "carregador portatil"]),
        ("Suportes Veiculares para Celular", ["suporte veicular", "suporte carro"]),
        ("Suportes para Celular", ["suporte celular", "suporte tablet"]),
        ("Controles Remotos Universais", ["controle remoto", "controle universal"]),
        ("Controles e Gamepads", ["gamepad", "controle gamer", "joystick"]),
        ("Mouse Sem Fio e Gamer", ["mouse"]),
        ("Teclados Bluetooth e Gamer", ["teclado"]),
        ("Antenas Digitais", ["antena"]),
        ("Drones e Acessórios", ["drone"]),
        ("Lanternas Táticas e Portáteis", ["lanterna"]),
        ("Caneca Copos e Garrafas", ["caneca", "copo térmico", "garrafa térmica"]),
        ("Camiseta", ["camiseta"]),
        ("Aparadores de Pelos", ["aparador", "depilador"]),
        ("Máquinas de Cortar Cabelo e Barba", ["maquina cortar", "máquina cortar", "barbeador", "cortador cabelo"]),
        ("Calculadoras e Papelaria", ["calculadora", "papelaria"]),
        ("Acessórios para Bicicleta e Ciclismo", ["bicicleta", "ciclismo"]),
        ("Eletrônicos", ["bluetooth", "wifi", "wireless", "led", "lcd", "adaptador", "stylus", "caneta touch"]),
        ("Casa e Decoração", ["organizador", "caixa porta"]),
        ("Beleza e Cuidado Pessoal", ["peeling", "ultrassônico", "cravos", "acne", "cabelo"]),
    ]
    for cat_name, kws in keyword_map:
        if any(k in title_lower for k in kws):
            existing = next((c for c in cats if (c.get("descricao") or "").lower() == cat_name.lower()), None)
            if existing:
                await add_log("info", f"Categoria (fallback): {existing['descricao']} (id={existing['id']})")
                return existing["id"]
            existing = next((c for c in cats if cat_name.lower() in (c.get("descricao") or "").lower()), None)
            if existing:
                return existing["id"]
    await add_log("info", "Nenhuma categoria existente combinou — produto ficará sem categoria (regra do manual).")
    return None


async def find_bling_product_by_sku(sku: str, max_attempts: Optional[int] = None) -> Optional[dict]:
    """Find a Bling product by codigo (SKU). Retries to wait for JohnDrop→Bling sync."""
    attempts = FIND_PRODUCT_MAX_ATTEMPTS if max_attempts is None else max(1, int(max_attempts))
    for attempt in range(attempts):
        resp = await bling_service.bling_request("GET", "/produtos", params={"codigo": sku, "limite": 5})
        if resp.status_code < 400:
            body = resp.json()
            items = body.get("data") or []
            for it in items:
                if (it.get("codigo") or "").strip().upper() == sku.upper():
                    return it
        if attempt < FIND_PRODUCT_MAX_ATTEMPTS - 1:
            await asyncio.sleep(FIND_PRODUCT_DELAY_S)
    return None


_SUPPLIER_CACHE: dict = {}


async def update_bling_product(
    product_id: int,
    current: dict,
    payload: dict,
    johndrop_id: Optional[str] = None,
    cost: Optional[float] = None,
    variations: Optional[List[str]] = None,
    images: Optional[list] = None,
    raw_title: str = "",
    raw_description: str = "",
    supplier_name: str = "JONH VARIEDADES",
) -> bool:
    """PATCH the Bling product, sending ONLY the fields the TotyShop manual asks
    us to change. Every other field stays EXACTLY as it came from JohnDrop.

    Fields we touch:
      1. descricaoCurta (sanitized + bullets)
      2. descricaoComplementar (8 bullets + Ficha Técnica com atributos IA)
      3. marca (marca real do fabricante OU nome da loja, conforme Configurações → Marca)
      4. condicao = 1 (Novo)
      5. tipoProducao = "T" (Terceiros)
      6. gtin = ""
      7. gtinEmbalagem = ""
      (+ categoria when LLM matched one, + fornecedor via separate endpoint)
    """
    parent_name = current.get("nome") or ""

    # Resolve a marca conforme o modo escolhido pelo usuário (item 4).
    marca = await _resolve_brand(raw_title, raw_description)
    # Se solicitado, extrai atributos (modelo, material, cor, voltagem, dimensoes,
    # palavras-chave) via IA para preencher cadastros de marketplace (item 5).
    attributes: dict = {}
    if payload.get("_extract_attributes"):
        attributes = await _extract_attributes(raw_title, raw_description)

    # Build a STRICTLY MINIMAL PATCH — never include nome, código, preço, peso,
    # dimensões, imagens, estoque, formato, etc.
    patch_payload: dict = {
        "marca": marca,
        "condicao": 1,
        "tipoProducao": "T",
        "gtin": "",
        "gtinEmbalagem": "",
    }
    if payload.get("descricaoCurta"):
        patch_payload["descricaoCurta"] = payload["descricaoCurta"]
    if payload.get("descricaoComplementar"):
        complementar = payload["descricaoComplementar"]
        # Anexa Ficha Técnica com os atributos extraídos pela IA (item 5).
        if attributes:
            ficha = _attributes_to_bullets(attributes)
            if ficha:
                complementar = complementar + "\n\n<b>Ficha Técnica:</b>\n" + "\n".join(ficha)
        patch_payload["descricaoComplementar"] = complementar
    if payload.get("categoria"):
        patch_payload["categoria"] = payload["categoria"]

    # IMAGENS: API v3 do Bling NÃO permite upload de imagens via PATCH ou PUT
    # em produtos existentes (testado e confirmado: status 200 mas Bling
    # silentemente ignora). Imagens chegam exclusivamente via sync JohnDrop→Bling
    # (que pode demorar de segundos a minutos). Nossa lógica em
    # _wait_for_johndrop_sync já aguarda isso. Se sync não completar dentro do
    # tempo limite, o produto fica sem imagens — único workaround é o usuário
    # fazer upload manual no Bling Dashboard.
    _ = images  # kept for API signature compatibility

    # Supplier collected here, applied AFTER the patch succeeds (separate endpoint)
    supplier_id = await _find_supplier_id(supplier_name)
    supplier_entry: Optional[dict] = None
    if supplier_id:
        supplier_entry = {
            "produto": {"id": product_id},
            "fornecedor": {"id": supplier_id},
            "descricao": parent_name[:120],
            "padrao": True,
            "garantia": 0,
        }
        if johndrop_id:
            supplier_entry["codigo"] = str(johndrop_id)
        if cost and cost > 0:
            supplier_entry["precoCusto"] = round(float(cost), 2)
            supplier_entry["precoCompra"] = round(float(cost), 2)

    # Send PATCH — this is parcial, never overwrites unspecified fields
    resp = await bling_service.bling_request(
        "PATCH", f"/produtos/{product_id}", json=patch_payload,
    )
    if resp.status_code >= 400:
        await add_log("warning", f"Bling {product_id}: HTTP {resp.status_code} — {resp.text[:800]}")
        return False

    # AFTER successful PATCH: link supplier (JONH VARIEDADES) via dedicated endpoint.
    if supplier_entry:
        try:
            sr = await bling_service.bling_request(
                "POST", "/produtos/fornecedores", json=supplier_entry,
            )
            if sr.status_code >= 400 and "já" not in sr.text.lower():
                await add_log(
                    "info",
                    f"Bling fornecedor {product_id}: HTTP {sr.status_code} — {sr.text[:200]}",
                )
        except Exception as e:
            await add_log("info", f"Bling fornecedor {product_id}: {e}")

    return True


async def _fetch_bling_product_full(product_id: int) -> Optional[dict]:
    resp = await bling_service.bling_request("GET", f"/produtos/{product_id}")
    if resp.status_code >= 400:
        return None
    body = resp.json()
    return body.get("data")


async def _save_log(sku: str, status: str, message: str, **fields) -> None:
    doc = {
        "id": str(uuid.uuid4()),
        "sku": sku,
        "status": status,
        "message": message,
        "created_at": datetime.now(timezone.utc).isoformat(),
        **fields,
    }
    await db.bling_enrichment_logs.insert_one(doc)


async def _upsert_enriched_cache(product_id: int, sku: str) -> None:
    """Cache product metadata after successful enrichment so /ad/products is fast.

    Without this cache, listing enriched products requires GET /produtos/{id}
    for each item (N+1 queries against Bling). With the cache, the listing
    becomes a single MongoDB query.
    """
    try:
        full = await _fetch_bling_product_full(product_id)
        if not full:
            return
        # Skip variation children — only cache parents/simples
        if (full.get("produtoPai") or {}).get("id"):
            return
        nome = (full.get("nome") or "").strip()
        if re.search(r"\b(Cor|Tamanho|Modelo|Voltagem):", nome):
            return

        img_url = ""
        midia = full.get("midia") or {}
        imgs = midia.get("imagens") or {}
        for img in (imgs.get("internas") or []):
            link = img.get("link") or img.get("linkMiniatura") or ""
            if link:
                img_url = link
                break
        if not img_url:
            for img in (imgs.get("externas") or []):
                link = img.get("link") or ""
                if link:
                    img_url = link
                    break

        await db.bling_enriched_cache.update_one(
            {"product_id": product_id},
            {"$set": {
                "product_id": product_id,
                "sku": (full.get("codigo") or sku or "").strip(),
                "nome": nome,
                "preco": full.get("preco") or 0,
                "image_url": img_url,
                "descricao_curta": (full.get("descricaoCurta") or "")[:200],
                "marca": full.get("marca") or "",
                "enriched_at": datetime.now(timezone.utc).isoformat(),
            }},
            upsert=True,
        )
    except Exception as e:
        await add_log("info", f"Cache enriched falhou para pid={product_id}: {e}")


async def _wait_for_johndrop_sync(
    product_id: int, sku: str,
    max_attempts: int = 20, delay_s: float = 15.0,
) -> dict:
    """Wait until JohnDrop finishes syncing the product into Bling.

    "Done syncing" = the product has either:
      • estoque saldoVirtualTotal > 0  (stock arrived), OR
      • at least 1 image in midia.imagens.internas/externas  (images arrived)

    Either signal means JohnDrop's async sync has reached this product and
    it's safe to convert to formato=V (which zeros simple stock) and to PATCH
    images onto variation children.

    Default budget: 12 × 15s = 180s (3 minutes), enough for most syncs.
    Returns the latest full product dict regardless of timeout.
    """
    import asyncio as _asyncio

    async def _read_full() -> Optional[dict]:
        try:
            r = await bling_service.bling_request("GET", f"/produtos/{product_id}")
            if r.status_code >= 400:
                return None
            return (r.json() or {}).get("data") or None
        except Exception:
            return None

    async def _read_saldo() -> int:
        try:
            r = await bling_service.bling_request(
                "GET", "/estoques/saldos", params={"idsProdutos[]": product_id},
            )
            if r.status_code >= 400:
                return 0
            rows = (r.json() or {}).get("data") or []
            if not rows:
                return 0
            v = rows[0].get("saldoVirtualTotal") or rows[0].get("saldoFisicoTotal") or 0
            return int(v) if v else 0
        except Exception:
            return 0

    def _img_count(p: Optional[dict]) -> int:
        if not p:
            return 0
        imgs = (p.get("midia") or {}).get("imagens") or {}
        return len(imgs.get("internas") or []) + len(imgs.get("externas") or [])

    # First read — many products already have both ready when we get here
    full = await _read_full()
    saldo = await _read_saldo()
    imgs = _img_count(full)
    if saldo > 0 or imgs > 0:
        await add_log(
            "info",
            f"Sync JohnDrop→Bling completo para {sku}: estoque={saldo}, imagens={imgs}",
        )
        return full or {}

    # Poll loop
    for attempt in range(1, max_attempts + 1):
        await add_log(
            "info",
            f"Aguardando sync JohnDrop→Bling de {sku} "
            f"(tentativa {attempt}/{max_attempts}, espera {delay_s:.0f}s) — "
            f"estoque={saldo}, imagens={imgs}",
        )
        await _asyncio.sleep(delay_s)
        full = await _read_full() or full
        saldo = await _read_saldo()
        imgs = _img_count(full)
        if saldo > 0 or imgs > 0:
            await add_log(
                "success",
                f"Sync JohnDrop→Bling completou para {sku} após {attempt * delay_s:.0f}s: "
                f"estoque={saldo}, imagens={imgs}",
            )
            return full or {}

    await add_log(
        "warning",
        f"Sync JohnDrop→Bling NÃO completou para {sku} após "
        f"{max_attempts * delay_s:.0f}s (estoque={saldo}, imagens={imgs}). "
        "PRÓXIMO PASSO: aguarde 5-10 min e rode 'Enriquecer em Lote' selecionando "
        f"o {sku} novamente — quando o JohnDrop terminar o sync, vai funcionar.",
    )
    return full or {}


async def enrich_product_by_sku(
    sku: str,
    raw_title: str,
    raw_description: str = "",
    johndrop_id: Optional[str] = None,
    cost: Optional[float] = None,
    images: Optional[list] = None,
    wait_for_product: bool = True,
    supplier_name: Optional[str] = None,
) -> dict:
    """Main enrichment flow. Idempotent — finds product, enriches it, logs result."""
    sku = (sku or "").strip()
    if not sku:
        return {"ok": False, "reason": "sku vazio"}

    # Persist the raw_description AT THE START so bulk re-enrichment can recover it
    # later (Bling stores enriched HTML in descricaoCurta — the original variation
    # text from JohnDrop ends up lost otherwise). We upsert by SKU so subsequent
    # runs don't duplicate the record.
    if raw_description and len(raw_description) > 30:
        supplier_name = (supplier_name or "JONH VARIEDADES").strip()
        try:
            await db.product_raw.update_one(
                {"sku": sku},
                {"$set": {
                    "sku": sku,
                    "raw_title": raw_title,
                    "raw_description": raw_description,
                    "johndrop_id": johndrop_id,
                    "cost": cost,
                    "images": images,
                    "supplier_name": supplier_name,
                    "updated_at": datetime.now(timezone.utc).isoformat(),
                }},
                upsert=True,
            )
        except Exception as e:
            await add_log("warning", f"Falhou ao persistir raw para {sku}: {e}")

    # If caller passed empty raw_description (typical of bulk re-enrich after a
    # restart), try to load the persisted version from Mongo.
    if not raw_description or len(raw_description) < 30:
        try:
            doc = await db.product_raw.find_one({"sku": sku})
            if doc:
                raw_description = doc.get("raw_description") or raw_description
                johndrop_id = johndrop_id or doc.get("johndrop_id")
                cost = cost if cost is not None else doc.get("cost")
                if not images:
                    images = doc.get("images")
                supplier_name = supplier_name or doc.get("supplier_name") or "JONH VARIEDADES"
                if raw_description:
                    await add_log("info", f"Bling: raw recuperado do Mongo para {sku} ({len(raw_description)} chars)")
        except Exception:
            pass

    supplier_name = (supplier_name or "JONH VARIEDADES").strip()

    # Track for live dashboard
    try:
        from enrichment_tracker import track as _track
        _track(sku, "queued", title=raw_title[:80])
    except Exception:
        _track = lambda *a, **k: None  # noqa: E731

    await add_log("info", f"Bling: iniciando enriquecimento para SKU {sku}")

    try:
        product = await find_bling_product_by_sku(
            sku, max_attempts=FIND_PRODUCT_MAX_ATTEMPTS if wait_for_product else 2,
        )
    except Exception as e:
        await add_log("error", f"Bling: erro ao buscar produto {sku}: {e}")
        await _save_log(sku, "error", f"busca falhou: {e}")
        _track(sku, "failed", error=f"busca: {e}")
        return {"ok": False, "reason": str(e)}

    if not product:
        msg = f"Produto {sku} não encontrado no Bling após {FIND_PRODUCT_MAX_ATTEMPTS} tentativas (~{FIND_PRODUCT_MAX_ATTEMPTS * FIND_PRODUCT_DELAY_S}s)"
        await add_log("warning", msg)
        await _save_log(sku, "not_found", msg)
        _track(sku, "failed", error="not_found")
        return {"ok": False, "reason": "not_found"}

    product_id = product.get("id")
    _track(sku, "waiting_sync", product_id=product_id)

    # Wait for JohnDrop async sync to bring in stock + images.
    if wait_for_product:
        full_after_sync = await _wait_for_johndrop_sync(product_id, sku)
    else:
        full_after_sync = await _fetch_bling_product_full(product_id) or product
    bling_imgs = (full_after_sync.get("midia") or {}).get("imagens") or {}
    bling_internal = [(i.get("link") or "") for i in (bling_imgs.get("internas") or [])]
    bling_external = [(i.get("link") or "") for i in (bling_imgs.get("externas") or [])]
    bling_urls = [u for u in (bling_internal + bling_external) if u]
    if bling_urls:
        images = bling_urls
    sync_saldo = (full_after_sync.get("estoque") or {}).get("saldoVirtualTotal") or 0
    _track(sku, "enriching", product_id=product_id,
           saldo=int(sync_saldo) if sync_saldo else 0,
           imagens=len(bling_urls))

    llm_failed = False
    llm_error = None
    try:
        short_desc, bullets, category_id = await asyncio.gather(
            generate_short_description(raw_title, raw_description),
            generate_bullet_points(raw_title, raw_description),
            pick_or_create_category(raw_title, raw_description),
        )
    except Exception as e:
        # LLM falhou (saldo esgotado, rate limit, etc). Em vez de abortar tudo,
        # aplica APENAS os campos que não dependem de LLM (marca, condição,
        # tipoProducao, fornecedor, variações) — assim o produto não fica com
        # dados errados de origem (Kapbom / Própria / Não Especificado).
        llm_failed = True
        llm_error = str(e)[:200]
        await add_log("error",
                      f"Bling: LLM falhou para {sku} — aplicando só metadados "
                      f"(marca/condição/produção/fornecedor). Erro: {llm_error}")
        short_desc, bullets, category_id = "", [], None

    # Bling renders HTML in description fields — convert newlines to <br>
    short_desc_html = short_desc.replace("\n\n", "<br><br>").replace("\n", "<br>") if short_desc else ""
    complementar_html = "<br>".join(bullets) if bullets else ""
    payload: dict = {}
    if short_desc_html:
        payload["descricaoCurta"] = short_desc_html
    if complementar_html:
        payload["descricaoComplementar"] = complementar_html
    if category_id:
        payload["categoria"] = {"id": category_id}

    try:
        # Use the post-sync full product instead of an extra GET (the wait
        # already returned the latest version).
        full = full_after_sync or await _fetch_bling_product_full(product_id) or product

        # ITEM 2 — sortido/conforme estoque: não cria variações nem SKUs separados.
        # Cadastra como produto simples e avisa na descrição que é sortido.
        is_sortido = _is_sortido(raw_description)
        variations: List[str] = []
        if not is_sortido:
            variations = _parse_variations(raw_description)
            if variations:
                # ITEM 1 — confirmação de cor por visão IA antes de criar variações.
                color_candidates = [v for v in variations if _is_color_name(v)]
                non_color = [v for v in variations if not _is_color_name(v)]
                confirmed_colors: List[str] = []
                if color_candidates:
                    confirmed = await _confirm_colors_by_vision(images, color_candidates)
                    confirmed_set = set(confirmed)
                    confirmed_colors = [c for c in color_candidates if _normalize_color_for_vision(c) in confirmed_set]
                    rejected = [c for c in color_candidates if c not in confirmed_colors]
                    if rejected:
                        await add_log(
                            "warning",
                            f"Cor não confirmada nas fotos (revisão) para {sku}: {', '.join(rejected)}",
                        )
                        await _save_review(sku, "cor_nao_confirmada", rejected, raw_title, raw_description, images)
                variations = non_color + confirmed_colors
                if variations:
                    await add_log(
                        "info",
                        f"Variações detectadas para {sku}: {', '.join(variations)}",
                    )
        else:
            await add_log(
                "info",
                f"Produto {sku} é SORTIDO/conforme estoque — sem variações, SKU único.",
            )
            if short_desc:
                sortido_note = "Produto sortido: cor/modelo enviado conforme estoque (vendedor não escolhe)."
                short_desc_html = (short_desc_html + "<br><br>" + sortido_note) if short_desc_html else sortido_note

        ok = await update_bling_product(
            product_id, full, payload,
            johndrop_id=johndrop_id, cost=cost, variations=variations or None,
            images=images,
            raw_title=raw_title, raw_description=raw_description,
            supplier_name=supplier_name,
        )
    except Exception as e:
        await add_log("error", f"Bling: PUT falhou para {sku}: {e}")
        await _save_log(sku, "error", f"PUT: {e}", product_id=product_id)
        _track(sku, "failed", error=f"PUT: {e}")
        return {"ok": False, "reason": str(e)}

    if ok:
        status_msg = "enriquecido (parcial: LLM falhou)" if llm_failed else "enriquecido"
        await add_log(
            "warning" if llm_failed else "success",
            f"Bling {status_msg}: {sku} (cat={category_id})",
        )
        # Marca no enrich_pending que este produto precisa retry LLM depois
        if llm_failed:
            try:
                from db import db as _db
                await _db.enrich_pending.update_one(
                    {"sku": sku},
                    {"$set": {"needs_llm_retry": True, "llm_last_error": llm_error}},
                )
            except Exception:
                pass
        await _save_log(
            sku, "success", "enriquecido",
            product_id=product_id,
            short_description=short_desc,
            bullets=bullets,
            category_id=category_id,
            johndrop_id=johndrop_id,
            cost=cost,
            variations=variations,
        )
        # Cache for fast /ad/products listing
        await _upsert_enriched_cache(product_id, sku)
        # AFTER successful enrichment: try to create variations (color/size).
        # This NEVER raises — if Bling rejects, only a warning is logged.
        variations_created = 0
        if variations:
            try:
                import bling_variations
                # Re-fetch product to get latest state (after the PUT just done)
                latest = await _fetch_bling_product_full(product_id) or full
                # Parse explicit per-variation quantities from description (e.g. "Rosa: 5")
                explicit_qty = _parse_variation_quantities(raw_description, variations)
                if explicit_qty:
                    await add_log(
                        "info",
                        f"Quantidades específicas detectadas: {explicit_qty}",
                    )
                result = await bling_variations.create_variations(
                    product_id, latest, variations, total_stock=0,
                    parent_images=images, explicit_quantities=explicit_qty or None,
                )
                variations_created = result.get("created", 0)
            except Exception as e:
                await add_log("warning", f"Variações pós-enrich falharam para {sku}: {e}")
        _track(sku, "done", product_id=product_id,
               variations_detected=len(variations) if variations else 0,
               variations_created=variations_created)
        return {
            "ok": True,
            "product_id": product_id,
            "category_id": category_id,
            "variations_detected": len(variations) if variations else 0,
            "variations_created": variations_created,
        }

    await add_log("warning", f"Bling: PUT retornou erro para {sku}")
    await _save_log(sku, "error", "PUT retornou status >= 400", product_id=product_id)
    _track(sku, "failed", error="put_failed")
    return {"ok": False, "reason": "put_failed"}


async def get_enrichment_logs(limit: int = 100) -> list:
    cur = db.bling_enrichment_logs.find({}, {"_id": 0}).sort("created_at", -1).limit(limit)
    return await cur.to_list(limit)


async def get_enrichment_stats() -> dict:
    total = await db.bling_enrichment_logs.count_documents({})
    success = await db.bling_enrichment_logs.count_documents({"status": "success"})
    errors = await db.bling_enrichment_logs.count_documents({"status": "error"})
    not_found = await db.bling_enrichment_logs.count_documents({"status": "not_found"})
    return {"total": total, "success": success, "errors": errors, "not_found": not_found}
